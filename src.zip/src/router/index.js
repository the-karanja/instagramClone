import { createRouter, createWebHistory } from 'vue-router'
import Login from '@/components/auth/Login.vue'
import Register from '@/components/auth/Register.vue'
import CreatorDashboard from '@/views/CreatorDashboard.vue'
import ConsumerFeed from '@/views/ConsumerFeed.vue'
import UploadView from '@/components/upload/UploadView.vue'
const routes = [
  {
    path: '/login',
    component: Login
  },
   {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/dashboard',
    name: 'CreatorDashboard',
    component: CreatorDashboard
  },
  {
    path: '/feed',
    name: 'ConsumerFeed',
    component: ConsumerFeed
  },
  {
    path: '/upload',
    name: 'Upload',
    component: UploadView
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router