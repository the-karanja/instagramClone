<template>
  <div>

    <!-- Page Title -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="fw-bold">Creator Dashboard</h2>

   <button class="btn btn-primary" @click="$router.push('/upload')">
  + New Upload
</button>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4 mb-4">

      <div class="col-md-3">
        <div class="card shadow-sm border-0">
          <div class="card-body">
            <h6 class="text-muted">Total Media</h6>
            <h3 class="fw-bold">128</h3>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card shadow-sm border-0">
          <div class="card-body">
            <h6 class="text-muted">Views</h6>
            <h3 class="fw-bold">24.5K</h3>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card shadow-sm border-0">
          <div class="card-body">
            <h6 class="text-muted">Comments</h6>
            <h3 class="fw-bold">342</h3>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card shadow-sm border-0">
          <div class="card-body">
            <h6 class="text-muted">Average Rating</h6>
            <h3 class="fw-bold">4.6 ⭐</h3>
          </div>
        </div>
      </div>

    </div>

    <!-- Analytics Section -->
    <div class="card shadow-sm border-0 mb-4">
      <div class="card-body">
        <h5 class="fw-bold mb-3">Performance Overview</h5>

        <div class="bg-light p-5 text-center text-muted rounded">
          Chart Area (we can integrate Chart.js later)
        </div>
      </div>
    </div>

    <!-- Recent Uploads -->
    <div class="card shadow-sm border-0">
      <div class="card-body">

        <h5 class="fw-bold mb-3">Recent Uploads</h5>

        <div class="table-responsive">
          <table class="table align-middle">
            <thead>
              <tr>
                <th>Title</th>
                <th>Views</th>
                <th>Rating</th>
                <th>Status</th>
              </tr>
            </thead>

            <tbody>
              <tr>
                <td>Summer Vibes</td>
                <td>5,210</td>
                <td>4.8</td>
                <td><span class="badge bg-success">Published</span></td>
              </tr>

              <tr>
                <td>Travel Reel</td>
                <td>3,120</td>
                <td>4.5</td>
                <td><span class="badge bg-success">Published</span></td>
              </tr>

              <tr>
                <td>Draft Video</td>
                <td>—</td>
                <td>—</td>
                <td><span class="badge bg-warning text-dark">Draft</span></td>
              </tr>
            </tbody>
          </table>
        </div>

      </div>
    </div>

  </div>
</template>

<script setup>
</script>