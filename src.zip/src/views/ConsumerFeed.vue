<template>
  <div>
    <h2 class="mb-4">Explore</h2>

    <!-- Grid view -->
    <MediaGrid
      v-if="!selected"
      :items="mediaList"
      @select="openMedia"
    />

    <!-- Fullscreen modal view -->
    <MediaViewer
      v-if="selected"
      :media="selected"
      @close="selected = null"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import MediaGrid from '@/components/media/MediaGrid.vue'
import MediaViewer from '@/components/media/MediaViewer.vue'

const selected = ref(null)

// Sample media list
const mediaList = ref([
  {
    id: 1,
    title: 'Summer Vibes',
    description: 'A relaxing summer video.',
    thumbnail: 'https://picsum.photos/400/300',
    views: 5210,
    rating: 4.8
  },
  {
    id: 2,
    title: 'Travel Reel',
    description: 'Exploring new cities.',
    thumbnail: 'https://picsum.photos/401/300',
    views: 3120,
    rating: 4.5
  }
])

// Open media modal
const openMedia = (media) => {
  selected.value = media
}
</script>