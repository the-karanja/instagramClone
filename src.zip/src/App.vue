<template>
  <AppHeader @toggle-sidebar="toggleSidebar" />

  <div class="d-flex">
    <Sidebar v-if="showSidebar" />

    <Container>
      <router-view />
    </Container>
  </div>
</template>

<script setup>
import { ref } from 'vue'

import AppHeader from '@/components/layout/AppHeader.vue'
import Sidebar from '@/components/layout/Sidebar.vue'
import Container from '@/components/layout/Container.vue'

const showSidebar = ref(true)

const toggleSidebar = () => {
  showSidebar.value = !showSidebar.value
}
</script>