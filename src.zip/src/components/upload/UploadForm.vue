<template>
  <div class="card p-4 shadow">

    <!-- File Input -->
    <div class="mb-3">
      <label class="form-label">Select Image</label>
      <input
        type="file"
        class="form-control"
        accept="image/*"
        @change="handleFile"
      />
    </div>

    <!-- Preview -->
    <UploadPreview
      v-if="previewUrl"
      :image="previewUrl"
    />

    <!-- Metadata -->
    <MetadataForm v-model="metadata" />

    <!-- Submit -->
    <button
      class="btn btn-dark w-100 mt-3"
      @click="upload"
      :disabled="!file"
    >
      Publish
    </button>

  </div>
</template>

<script setup>
import { ref } from 'vue'
import UploadPreview from './UploadPreview.vue'
import MetadataForm from './MetadataForm.vue'

const file = ref(null)
const previewUrl = ref(null)

const metadata = ref({
  title: '',
  caption: '',
  location: '',
  people: ''
})

const handleFile = (event) => {
  file.value = event.target.files[0]
  previewUrl.value = URL.createObjectURL(file.value)
}

const upload = () => {
  const formData = new FormData()

  formData.append('image', file.value)
  formData.append('title', metadata.value.title)
  formData.append('caption', metadata.value.caption)
  formData.append('location', metadata.value.location)
  formData.append('people', metadata.value.people)

  console.log('Ready to send to backend')

  // Later: send to API
}
</script>