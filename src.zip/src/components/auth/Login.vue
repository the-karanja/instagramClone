<template>
  <div class="container d-flex justify-content-center align-items-center min-vh-100">

    <div class="card shadow p-4" style="width: 400px;">

      <h3 class="text-center mb-4">Login</h3>

      <form @submit.prevent="handleLogin">

        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" class="form-control" v-model="email" required />
        </div>

        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" v-model="password" required />
        </div>

        <button class="btn btn-dark w-100">
          Login
        </button>

      </form>

      <hr />

      <p class="text-center mb-0">
        Don't have an account?
        <router-link to="/register">
          Sign up
        </router-link>
      </p>

    </div>

  </div>
</template>

<script setup>
import { ref } from 'vue'

const email = ref('')
const password = ref('')
const role = ref('consumer')

const handleLogin = () => {
  const payload = {
    email: email.value,
    password: password.value,
    role: role.value
  }

  console.log(payload)

  // Later: send to backend API
}
</script>