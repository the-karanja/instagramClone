<template>
  <div class="container">
    <div class="row justify-content-center mt-5">
      <div class="col-md-5">

        <div class="card shadow-sm">
          <div class="card-body">

            <h3 class="text-center mb-4">Create Account</h3>

            <form @submit.prevent="handleRegister">

              <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input 
                  v-model="form.name" 
                  type="text" 
                  class="form-control" 
                  required 
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Email</label>
                <input 
                  v-model="form.email" 
                  type="email" 
                  class="form-control" 
                  required 
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Password</label>
                <input 
                  v-model="form.password" 
                  type="password" 
                  class="form-control" 
                  required 
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Confirm Password</label>
                <input 
                  v-model="form.confirmPassword" 
                  type="password" 
                  class="form-control" 
                  required 
                />
              </div>

              <div v-if="error" class="alert alert-danger">
                {{ error }}
              </div>

              <button type="submit" class="btn btn-primary w-100">
                Register
              </button>

              <p class="text-center mt-3 mb-0">
                Already have an account?
                <router-link to="/login">
                  Sign in
                </router-link>
              </p>

            </form>

          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'

const form = reactive({
  name: '',
  email: '',
  password: '',
  confirmPassword: ''
})

const error = ref('')

const handleRegister = () => {
  error.value = ''

  if (form.password !== form.confirmPassword) {
    error.value = 'Passwords do not match'
    return
  }

  // Here you would normally send data to your API
  console.log('Register Data:', form)

  alert('Account created successfully!')
}
</script>

<style scoped>
.register-container {
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 8px;
}

.form-group {
  margin-bottom: 15px;
}

input {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
}

button {
  width: 100%;
  padding: 10px;
  background: black;
  color: white;
  border: none;
  cursor: pointer;
}

.error {
  color: red;
}
</style>