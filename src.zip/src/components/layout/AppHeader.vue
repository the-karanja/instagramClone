<template>
  <!-- <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-3">
    <a class="navbar-brand" href="#">MediaApp</a>

    <div class="ms-auto">
      <button class="btn btn-outline-light btn-sm">
        Logout
      </button>
    </div>
  </nav> -->
   <nav class="navbar navbar-dark bg-dark px-3">
    
    <button class="btn btn-outline-light btn-sm me-2"
      @click="$emit('toggle-sidebar')">
      ☰
    </button>

    <span class="navbar-brand mb-0">MediaApp</span>

  </nav>    
</template>

<script setup>
</script>